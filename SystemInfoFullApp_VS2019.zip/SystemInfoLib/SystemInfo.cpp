
#include <windows.h>
#include <string>
#include <sstream>
#include <intrin.h>

std::string GetMemoryInfo() {
    MEMORYSTATUSEX memInfo;
    memInfo.dwLength = sizeof(memInfo);
    GlobalMemoryStatusEx(&memInfo);
    DWORDLONG total = memInfo.ullTotalPhys / (1024 * 1024); // MB
    DWORDLONG avail = memInfo.ullAvailPhys / (1024 * 1024); // MB
    std::ostringstream oss;
    oss << "RAM: " << avail << " MB Free / " << total << " MB Total";
    return oss.str();
}

std::string GetDiskInfo() {
    ULARGE_INTEGER free, total, totalFree;
    GetDiskFreeSpaceEx(L"C:\\", &free, &total, &totalFree);
    std::ostringstream oss;
    oss << "Disk C: " << (free.QuadPart >> 30) << " GB Free / "
        << (total.QuadPart >> 30) << " GB Total";
    return oss.str();
}

std::string GetCPUInfo() {
    int cpuInfo[4] = {-1};
    char cpuBrandString[0x40] = {0};
    __cpuid(cpuInfo, 0x80000000);
    unsigned int nExIds = cpuInfo[0];
    if (nExIds >= 0x80000004) {
        __cpuid((int*)(cpuBrandString), 0x80000002);
        __cpuid((int*)(cpuBrandString + 16), 0x80000003);
        __cpuid((int*)(cpuBrandString + 32), 0x80000004);
    }
    return std::string("CPU: ") + cpuBrandString;
}
