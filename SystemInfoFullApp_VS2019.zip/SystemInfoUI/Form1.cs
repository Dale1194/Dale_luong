
using System;
using System.Windows.Forms;
using SystemInfoLib;

namespace SystemInfoUI
{
    public partial class Form1 : Form
    {
        Timer timer = new Timer();

        public Form1()
        {
            InitializeComponent();
            timer.Interval = 1000;
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            lblRAM.Text = SystemInfoWrapper.GetMemoryInfo();
            lblDisk.Text = SystemInfoWrapper.GetDiskInfo();
            lblCPU.Text = SystemInfoWrapper.GetCPUInfo();
        }
    }
}
