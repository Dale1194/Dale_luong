
namespace SystemInfoUI
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblRAM;
        private System.Windows.Forms.Label lblDisk;
        private System.Windows.Forms.Label lblCPU;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblRAM = new System.Windows.Forms.Label();
            this.lblDisk = new System.Windows.Forms.Label();
            this.lblCPU = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblRAM
            // 
            this.lblRAM.AutoSize = true;
            this.lblRAM.Location = new System.Drawing.Point(30, 30);
            this.lblRAM.Name = "lblRAM";
            this.lblRAM.Size = new System.Drawing.Size(35, 13);
            this.lblRAM.TabIndex = 0;
            this.lblRAM.Text = "RAM";
            // 
            // lblDisk
            // 
            this.lblDisk.AutoSize = true;
            this.lblDisk.Location = new System.Drawing.Point(30, 60);
            this.lblDisk.Name = "lblDisk";
            this.lblDisk.Size = new System.Drawing.Size(30, 13);
            this.lblDisk.TabIndex = 1;
            this.lblDisk.Text = "Disk";
            // 
            // lblCPU
            // 
            this.lblCPU.AutoSize = true;
            this.lblCPU.Location = new System.Drawing.Point(30, 90);
            this.lblCPU.Name = "lblCPU";
            this.lblCPU.Size = new System.Drawing.Size(29, 13);
            this.lblCPU.TabIndex = 2;
            this.lblCPU.Text = "CPU";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(400, 150);
            this.Controls.Add(this.lblCPU);
            this.Controls.Add(this.lblDisk);
            this.Controls.Add(this.lblRAM);
            this.Name = "Form1";
            this.Text = "System Info Monitor";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
