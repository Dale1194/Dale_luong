
#include "SystemInfo.cpp"
using namespace System;

public ref class SystemInfoWrapper
{
public:
    static String^ GetMemoryInfo() {
        return gcnew String(GetMemoryInfo().c_str());
    }

    static String^ GetDiskInfo() {
        return gcnew String(GetDiskInfo().c_str());
    }

    static String^ GetCPUInfo() {
        return gcnew String(GetCPUInfo().c_str());
    }
};
