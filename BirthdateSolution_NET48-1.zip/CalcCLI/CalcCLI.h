
#pragma once

namespace CalcCLI {
    public ref class AgeCalculator
    {
    public:
        static int CalculateAge(int year, int month, int day);
    };
}
