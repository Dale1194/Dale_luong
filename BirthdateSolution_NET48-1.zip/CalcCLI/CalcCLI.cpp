
#include "pch.h"
#include "CalcCLI.h"
#include <ctime>

using namespace System;

namespace CalcCLI {
    int AgeCalculator::CalculateAge(int year, int month, int day)
    {
        time_t t = time(nullptr);
        tm* now = localtime(&t);

        int age = now->tm_year + 1900 - year;
        if ((now->tm_mon + 1 < month) || ((now->tm_mon + 1 == month) && now->tm_mday < day)) {
            age--;
        }
        return age;
    }
}
