
using System;
using System.Windows.Forms;

namespace BirthdateApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            DateTime birthdate = dateTimePicker1.Value;
            int age = CalcCLI.AgeCalculator.CalculateAge(birthdate.Year, birthdate.Month, birthdate.Day);
            MessageBox.Show($"Tuổi của bạn là: {age} tuổi", "Kết quả");
        }
    }
}
