﻿// AgeCalculator.cpp
#include "pch.h" // Hoặc <windows.h> nếu không dùng precompiled headers
#include "AgeCalculator.h"
#include <ctime> // Để lấy ngày giờ hiện tại
#include <stdexcept> // Cho std::invalid_argument (tùy chọn, nếu muốn throw exception)

// Định nghĩa hàm đã khai báo trong AgeCalculator.h
extern "C" AGECALCULATOR_API int TinhTuoiCPP(int ngaySinh, int thangSinh, int namSinh) {
    time_t t = time(nullptr); // Lấy thời gian hiện tại
    tm nowLocal;
    localtime_s(&nowLocal, &t); // Chuyển đổi sang cấu trúc tm an toàn hơn

    int namHienTai = nowLocal.tm_year + 1900; // tm_year là số năm kể từ 1900
    int thangHienTai = nowLocal.tm_mon + 1;   // tm_mon là tháng từ 0-11 (nên +1)
    int ngayHienTai = nowLocal.tm_mday;

    // Kiểm tra ngày sinh cơ bản
    if (namSinh <= 0 || thangSinh <= 0 || thangSinh > 12 || ngaySinh <= 0 || ngaySinh > 31) {
        return -2; // Mã lỗi cho ngày/tháng/năm không hợp lệ
    }

    if (namSinh > namHienTai ||
        (namSinh == namHienTai && thangSinh > thangHienTai) ||
        (namSinh == namHienTai && thangSinh == thangHienTai && ngaySinh > ngayHienTai)) {
        return -1; // Ngày sinh ở tương lai
    }

    int tuoi(0);
    if (thangSinh > thangHienTai)
    {
        tuoi = (namHienTai - namSinh)+1;
    }
    else
    {
        tuoi = namHienTai - namSinh;
    }
    int thang(0);
    if (thangSinh > thangHienTai)
    {
        thang = thangSinh - thangHienTai;
    }
    else
    {
        thang = (12 - thangHienTai) + thangSinh;
    }

    if (thangHienTai < thangSinh || (thangHienTai == thangSinh && ngayHienTai < ngaySinh)) {
        tuoi--;
    }

    return tuoi;
}