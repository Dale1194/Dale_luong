﻿// AgeCalculator.h
#pragma once

// Macro sau được định nghĩa tự động bởi Visual Studio khi bạn tạo một dự án DLL.
// Nó đảm bảo rằng các hàm được đánh dấu với AGECALCULATOR_API sẽ được xuất (dllexport)
// khi xây dựng DLL, và được nhập (dllimport) khi một ứng dụng khác sử dụng DLL này.
#ifdef AGECALCULATORDLL_EXPORTS // Macro này thường được định nghĩa trong Project Properties -> C/C++ -> Preprocessor -> Preprocessor Definitions
#define AGECALCULATOR_API __declspec(dllexport)
#else
#define AGECALCULATOR_API __declspec(dllimport)
#endif

// Sử dụng extern "C" để C++ không "mangle" (thay đổi) tên hàm,
// giúp C# dễ dàng tìm và gọi hàm.
extern "C" AGECALCULATOR_API int TinhTuoiCPP(int ngaySinh, int thangSinh, int namSinh);
