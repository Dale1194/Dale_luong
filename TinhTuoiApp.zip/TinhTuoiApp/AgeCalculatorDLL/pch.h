﻿// pch.h
#ifndef PCH_H
#define PCH_H

// Thêm các header bạn muốn biên dịch trước vào đây
#include "framework.h" // Hoặc <windows.h> nếu không có framework.h

#endif //PCH_H