﻿using System;
using System.Windows.Forms;
using System.Runtime.InteropServices; // Cần cho DllImport

namespace TinhTuoiApp
{
    public partial class Form1 : Form
    {
        // Khai báo hàm C++ sẽ được gọi từ DLL
        // Đảm bảo "AgeCalculatorDLL.dll" là tên chính xác của tệp DLL bạn đã biên dịch
        // và nó nằm trong cùng thư mục với file .exe của ứng dụng C# hoặc trong PATH hệ thống.
        [DllImport("AgeCalculatorDLL.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int TinhTuoiCPP(int ngay, int thang, int nam);

        public Form1()
        {
            InitializeComponent();
        }

        private void btnTinhTuoi_Click(object sender, EventArgs e)
        {
            DateTime ngaySinhChon = dtpNgaySinh.Value;

            try
            {
                // Gọi hàm C++
                int tuoi = TinhTuoiCPP(ngaySinhChon.Day, ngaySinhChon.Month, ngaySinhChon.Year);
                int thang= TinhTuoiCPP(ngaySinhChon.Day, ngaySinhChon.Month, ngaySinhChon.Year);
                if (tuoi == -1)
                {
                    lblTuoi.Text = "Lỗi: Ngày sinh không thể ở tương lai.";
                }
                else if (tuoi == -2)
                {
                    lblTuoi.Text = "Lỗi: Ngày, tháng hoặc năm sinh không hợp lệ.";
                }
                else if (tuoi < 0) // Các mã lỗi khác nếu có
                {
                    lblTuoi.Text = "Lỗi không xác định khi tính tuổi.";
                }
                else
                {
                    lblTuoi.Text = $"Tuổi của bạn là: {tuoi} năm {thang} tháng ngày ";
                }
            }
            catch (DllNotFoundException)
            {
                lblTuoi.Text = "Lỗi: Không tìm thấy tệp AgeCalculatorDLL.dll.";
                MessageBox.Show("Không tìm thấy tệp AgeCalculatorDLL.dll. Hãy đảm bảo tệp này nằm trong cùng thư mục với ứng dụng hoặc trong PATH hệ thống.", "Lỗi DLL", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                lblTuoi.Text = $"Lỗi ngoại lệ: {ex.Message}";
                MessageBox.Show($"Đã xảy ra lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}