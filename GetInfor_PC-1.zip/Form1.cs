using System;
using System.Management;
using System.Text;
using System.Windows.Forms;

namespace ComputerInfoApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGetInfo_Click(object sender, EventArgs e)
        {
            StringBuilder info = new StringBuilder();
            info.AppendLine("===== THÔNG TIN HỆ THỐNG =====");
            info.AppendLine($"Tên máy: {Environment.MachineName}");
            info.AppendLine($"Người dùng: {Environment.UserName}");
            info.AppendLine($"Hệ điều hành: {Environment.OSVersion}");
            info.AppendLine();
            info.AppendLine("===== CPU =====");

            using (var searcher = new ManagementObjectSearcher("select * from Win32_Processor"))
            {
                foreach (var item in searcher.Get())
                {
                    info.AppendLine($"CPU: {item["Name"]}");
                }
            }

            textBox1.Text = info.ToString();
        }
    }
}
