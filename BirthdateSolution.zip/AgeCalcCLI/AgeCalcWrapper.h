#pragma once
using namespace System;
namespace AgeCalcCLI {
    public ref class AgeWrapper {
    public:
        static int CalculateAge(DateTime birthDate);
    };
}
