#include "AgeCalcWrapper.h"
#include "../AgeCalcNative/AgeCalculator.h"
int AgeCalcCLI::AgeWrapper::CalculateAge(System::DateTime birthDate) {
    return CalculateAge(birthDate.Day, birthDate.Month, birthDate.Year);
}
