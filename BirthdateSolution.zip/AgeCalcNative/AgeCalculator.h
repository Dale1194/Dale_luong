#pragma once
#include <ctime>
int CalculateAge(int day, int month, int year);
