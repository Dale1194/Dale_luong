#include "AgeCalculator.h"
int CalculateAge(int day, int month, int year) {
    time_t t = time(0);
    tm* now = localtime(&t);
    int curr_year = now->tm_year + 1900;
    int curr_month = now->tm_mon + 1;
    int curr_day = now->tm_mday;
    int age = curr_year - year;
    if (curr_month < month || (curr_month == month && curr_day < day)) age--;
    return age;
}
