namespace BirthdateApp {
    partial class Form1 {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btnOK;
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) { components.Dispose(); }
            base.Dispose(disposing);
        }
        private void InitializeComponent() {
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btnOK = new System.Windows.Forms.Button();
            this.SuspendLayout();
            this.dateTimePicker1.Location = new System.Drawing.Point(30, 30);
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.btnOK.Location = new System.Drawing.Point(250, 30);
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.Text = "OK";
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            this.ClientSize = new System.Drawing.Size(364, 91);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.dateTimePicker1);
            this.Text = "Tính tuổi";
            this.ResumeLayout(false);
        }
    }
}
