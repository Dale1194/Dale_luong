using System;
using System.Windows.Forms;
using AgeCalcCLI;
namespace BirthdateApp {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }
        private void btnOK_Click(object sender, EventArgs e) {
            DateTime dob = dateTimePicker1.Value;
            int age = AgeWrapper.CalculateAge(dob);
            MessageBox.Show("Tuổi của bạn là: " + age);
        }
    }
}
